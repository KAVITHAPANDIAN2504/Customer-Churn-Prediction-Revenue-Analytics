# config.py
DATABASE_CONFIG = {
    'host': 'localhost',
    'port': '2509',
    'database': 'telecom_analytics',
    'user': 'postgres',
    'password': '1234'  # Change this!
}

MODEL_CONFIG = {
    'test_size': 0.2,
    'random_state': 42,
    'cv_folds': 5
}

FEATURES = {
    'numeric': [
        'age', 'account_age_days', 'num_subscriptions', 'active_subscriptions',
        'avg_monthly_charges', 'total_spent', 'avg_data_usage', 'avg_call_minutes',
        'total_support_tickets', 'avg_satisfaction', 'failed_payments_count',
        'avg_late_fees'
    ],
    'categorical': ['customer_segment', 'gender', 'has_paperless_billing']
}