# src/database.py
import pandas as pd
from sqlalchemy import create_engine
from config import DATABASE_CONFIG

class PostgresConnection:
    def __init__(self):
        self.connection_string = (
            f"postgresql://{DATABASE_CONFIG['user']}:{DATABASE_CONFIG['password']}"
            f"@{DATABASE_CONFIG['host']}:{DATABASE_CONFIG['port']}"
            f"/{DATABASE_CONFIG['database']}"
        )
        self.engine = create_engine(self.connection_string)
    
    def get_ml_data(self):
        """Fetch data for machine learning"""
        query = "SELECT * FROM customer_risk_features"
        return pd.read_sql(query, self.engine)
    
    def get_customers(self):
        return pd.read_sql("SELECT * FROM customers", self.engine)
    
    def get_subscriptions(self):
        return pd.read_sql("SELECT * FROM subscriptions", self.engine)
    
    def execute_query(self, query):
        return pd.read_sql(query, self.engine)