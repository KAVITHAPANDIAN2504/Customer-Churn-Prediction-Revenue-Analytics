# src/features.py
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder

class FeatureEngineer:
    def __init__(self):
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.feature_columns = None
    
    def create_advanced_features(self, df):
        """Create new features from raw data"""
        df = df.copy()
        
        # Monetary features
        df['revenue_per_day'] = df['total_spent'] / (df['account_age_days'] + 1)
        df['subscription_ratio'] = df['active_subscriptions'] / (df['num_subscriptions'] + 0.1)
        
        # Usage features
        median_data = df['avg_data_usage'].median()
        df['is_high_usage'] = (df['avg_data_usage'] > median_data).astype(int)
        df['is_low_satisfaction'] = (df['avg_satisfaction'] < 5).astype(int)
        
        # Risk features
        df['has_payment_issues'] = (df['failed_payments_count'] > 0).astype(int)
        median_tickets = df['total_support_tickets'].median()
        df['high_support_tickets'] = (df['total_support_tickets'] > median_tickets).astype(int)
        
        # Interaction features
        df['spending_per_subscription'] = df['total_spent'] / (df['num_subscriptions'] + 0.1)
        df['age_account_interaction'] = df['age'] * np.log1p(df['account_age_days'])
        df['satisfaction_x_usage'] = df['avg_satisfaction'] * df['avg_data_usage']
        
        return df
    
    def preprocess(self, df, fit=True):
        """Preprocess data for ML"""
        df = df.copy()
        
        # Handle categorical variables
        cat_cols = ['customer_segment', 'gender', 'has_paperless_billing']
        
        for col in cat_cols:
            if col in df.columns:
                if fit:
                    self.label_encoders[col] = LabelEncoder()
                    df[col] = self.label_encoders[col].fit_transform(df[col].astype(str))
                else:
                    df[col] = self.label_encoders[col].transform(df[col].astype(str))
        
        # Select all numeric features
        exclude_cols = ['customer_id', 'has_churned', 'risk_category']
        self.feature_columns = [col for col in df.columns if col not in exclude_cols]
        
        X = df[self.feature_columns]
        y = df['has_churned']
        
        # Handle missing values
        X = X.fillna(X.median())
        
        # Scale features
        if fit:
            X_scaled = self.scaler.fit_transform(X)
        else:
            X_scaled = self.scaler.transform(X)
        
        return X_scaled, y, self.feature_columns