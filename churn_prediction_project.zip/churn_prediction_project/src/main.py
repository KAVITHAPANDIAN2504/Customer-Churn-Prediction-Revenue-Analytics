# main.py
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import numpy as np
from src.database import PostgresConnection
from src.features import FeatureEngineer
from src.models import ChurnModel

def main():
    print("🚀 Customer Churn Prediction Pipeline")
    print("=" * 60)
    
    # Step 1: Load Data
    print("\n📊 Step 1: Loading data from PostgreSQL...")
    db = PostgresConnection()
    raw_df = db.get_ml_data()
    
    # DEBUG: Check if data was loaded
    print(f"\n🔍 DEBUG: Raw DataFrame shape: {raw_df.shape}")
    print(f"🔍 DEBUG: Columns: {list(raw_df.columns)}")
    
    if raw_df.empty:
        print("\n❌ ERROR: No data loaded from database!")
        print("   Possible causes:")
        print("   1. The 'customer_risk_features' table doesn't exist")
        print("   2. The table is empty")
        print("   3. Database connection issue")
        
        # Try to check what tables exist
        print("\n🔍 DEBUG: Checking database connection...")
        try:
            # Try to get list of tables
            tables = db.execute_query("""
                SELECT table_name FROM information_schema.tables 
                WHERE table_schema = 'public'
            """)
            print(f"🔍 DEBUG: Available tables: {tables['table_name'].tolist() if not tables.empty else 'None'}")
        except Exception as e:
            print(f"❌ DEBUG: Error checking tables: {e}")
        
        return None, None, None
    
    print(f"✓ Loaded {len(raw_df)} customer records")
    print(f"✓ Churn rate: {raw_df['has_churned'].mean():.2%}")
    
    # Step 2: Feature Engineering
    print("\n🔧 Step 2: Engineering features...")
    engineer = FeatureEngineer()
    featured_df = engineer.create_advanced_features(raw_df)
    print(f"✓ Created {featured_df.shape[1]} total features")
    
    # Step 3: Preprocess
    print("\n⚙️  Step 3: Preprocessing data...")
    X, y, feature_names = engineer.preprocess(featured_df, fit=True)
    print(f"✓ Final feature matrix: {X.shape}")
    print(f"✓ Features: {', '.join(feature_names[:5])}...")
    
    # Step 4: Train Models
    print("\n🤖 Step 4: Training Machine Learning models...")
    model = ChurnModel()
    results, X_test, y_test = model.train_evaluate(X, y, feature_names)
    
    # Step 5: Visualize
    print("\n📈 Step 5: Generating visualizations...")
    model.plot_results()
    
    # Step 6: Save Model
    print("\n💾 Step 6: Saving model...")
    os.makedirs('models', exist_ok=True)
    model.save_model()
    
    # Step 7: Generate Business Insights
    print("\n" + "=" * 60)
    print("📋 BUSINESS INSIGHTS")
    print("=" * 60)
    
    # Feature importance insights
    if model.feature_importance is not None:
        print("\n🔍 Top 5 Churn Predictors:")
        for idx, row in model.feature_importance.head(5).iterrows():
            print(f"   {idx+1}. {row['feature']}: {row['importance']:.4f}")
    
    # Financial impact
    total_customers = len(raw_df)
    churned_customers = raw_df['has_churned'].sum()
    avg_revenue = raw_df['total_spent'].mean()
    revenue_at_risk = raw_df[raw_df['has_churned'] == 1]['total_spent'].sum()
    
    print(f"\n💰 Financial Impact:")
    print(f"   • Total customers analyzed: {total_customers:,}")
    print(f"   • Churned customers: {churned_customers:,} ({100*churned_customers/total_customers:.1f}%)")
    print(f"   • Average customer LTV: ${avg_revenue:,.2f}")
    print(f"   • Total revenue lost to churn: ${revenue_at_risk:,.2f}")
    
    # Risk segmentation
    predictions = model.predict(X)
    risk_dist = predictions['risk_level'].value_counts()
    print(f"\n⚠️  Risk Distribution (Predicted):")
    for risk, count in risk_dist.items():
        print(f"   • {risk} Risk: {count} customers ({100*count/len(predictions):.1f}%)")
    
    # Recommendations
    print(f"\n💡 Recommendations:")
    print(f"   1. Focus on customers with low satisfaction scores (< 5)")
    print(f"   2. Address payment issues proactively")
    print(f"   3. Target high-usage customers for upselling")
    print(f"   4. Implement retention campaigns for Medium/High risk segments")
    
    print("\n✅ Pipeline completed successfully!")
    return model, featured_df, predictions

if __name__ == "__main__":
    try:
        model, data, predictions = main()
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()