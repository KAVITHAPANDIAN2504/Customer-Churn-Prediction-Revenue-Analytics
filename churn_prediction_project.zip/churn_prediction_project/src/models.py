# src/model.py
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (classification_report, confusion_matrix, 
                             roc_auc_score, roc_curve, precision_recall_curve)
import joblib
from config import MODEL_CONFIG

class ChurnModel:
    def __init__(self):
        self.models = {
            'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
            'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1),
            'Gradient Boosting': GradientBoostingClassifier(random_state=42)
        }
        self.best_model = None
        self.best_model_name = None
        self.results = {}
        self.feature_importance = None
    
    def train_evaluate(self, X, y, feature_names):
        """Train and evaluate all models"""
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, 
            test_size=MODEL_CONFIG['test_size'], 
            random_state=MODEL_CONFIG['random_state'],
            stratify=y
        )
        
        print(f"Training set size: {len(X_train)}")
        print(f"Test set size: {len(X_test)}")
        print(f"Churn rate in training: {y_train.mean():.2%}")
        
        # Train each model
        for name, model in self.models.items():
            print(f"\n{'='*60}")
            print(f"Training: {name}")
            print('='*60)
            
            # Train
            model.fit(X_train, y_train)
            
            # Predict
            y_pred = model.predict(X_test)
            y_prob = model.predict_proba(X_test)[:, 1]
            
            # Metrics
            auc = roc_auc_score(y_test, y_prob)
            cv_scores = cross_val_score(
                model, X_train, y_train, 
                cv=StratifiedKFold(n_splits=MODEL_CONFIG['cv_folds']), 
                scoring='roc_auc'
            )
            
            # Store results
            self.results[name] = {
                'model': model,
                'auc': auc,
                'cv_mean': cv_scores.mean(),
                'cv_std': cv_scores.std(),
                'predictions': y_pred,
                'probabilities': y_prob,
                'y_test': y_test
            }
            
            print(f"AUC-ROC: {auc:.4f}")
            print(f"CV AUC: {cv_scores.mean():.4f} (+/- {cv_scores.std()*2:.4f})")
            print(f"\nClassification Report:")
            print(classification_report(y_test, y_pred, target_names=['No Churn', 'Churn']))
        
        # Select best model
        self.best_model_name = max(self.results, key=lambda x: self.results[x]['auc'])
        self.best_model = self.results[self.best_model_name]['model']
        
        print(f"\n{'='*60}")
        print(f"BEST MODEL: {self.best_model_name}")
        print(f"AUC-ROC: {self.results[self.best_model_name]['auc']:.4f}")
        print('='*60)
        
        # Feature importance
        if hasattr(self.best_model, 'feature_importances_'):
            self.feature_importance = pd.DataFrame({
                'feature': feature_names,
                'importance': self.best_model.feature_importances_
            }).sort_values('importance', ascending=False)
        
        return self.results, X_test, y_test
    
    def plot_results(self, save_path='models/model_performance.png'):
        """Visualize model performance"""
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        
        # 1. ROC Curves
        ax1 = axes[0, 0]
        for name, res in self.results.items():
            fpr, tpr, _ = roc_curve(res['y_test'], res['probabilities'])
            ax1.plot(fpr, tpr, label=f"{name} (AUC={res['auc']:.3f})", linewidth=2)
        ax1.plot([0, 1], [0, 1], 'k--', alpha=0.5)
        ax1.set_xlabel('False Positive Rate', fontsize=12)
        ax1.set_ylabel('True Positive Rate', fontsize=12)
        ax1.set_title('ROC Curves Comparison', fontsize=14, fontweight='bold')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # 2. Feature Importance
        ax2 = axes[0, 1]
        if self.feature_importance is not None:
            top_10 = self.feature_importance.head(10)
            colors = plt.cm.RdYlGn(np.linspace(0.2, 0.8, len(top_10)))
            bars = ax2.barh(top_10['feature'], top_10['importance'], color=colors)
            ax2.set_xlabel('Importance', fontsize=12)
            ax2.set_title('Top 10 Feature Importances', fontsize=14, fontweight='bold')
            ax2.invert_yaxis()
            # Add value labels
            for i, bar in enumerate(bars):
                width = bar.get_width()
                ax2.text(width, bar.get_y() + bar.get_height()/2, 
                        f'{width:.3f}', ha='left', va='center', fontsize=9)
        
        # 3. Confusion Matrix
        ax3 = axes[1, 0]
        best_res = self.results[self.best_model_name]
        cm = confusion_matrix(best_res['y_test'], best_res['predictions'])
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax3, 
                   xticklabels=['No Churn', 'Churn'],
                   yticklabels=['No Churn', 'Churn'])
        ax3.set_title(f'Confusion Matrix - {self.best_model_name}', fontsize=14, fontweight='bold')
        ax3.set_xlabel('Predicted', fontsize=12)
        ax3.set_ylabel('Actual', fontsize=12)
        
        # 4. Prediction Distribution
        ax4 = axes[1, 1]
        probs = best_res['probabilities']
        y_test = best_res['y_test']
        ax4.hist(probs[y_test==0], bins=30, alpha=0.6, label='No Churn', color='green', density=True)
        ax4.hist(probs[y_test==1], bins=30, alpha=0.6, label='Churn', color='red', density=True)
        ax4.axvline(x=0.5, color='black', linestyle='--', label='Threshold (0.5)')
        ax4.set_xlabel('Churn Probability', fontsize=12)
        ax4.set_ylabel('Density', fontsize=12)
        ax4.set_title('Prediction Distribution', fontsize=14, fontweight='bold')
        ax4.legend()
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"\n📊 Visualization saved to: {save_path}")
        plt.show()
        
        return fig
    
    def save_model(self, filepath='models/churn_model.pkl'):
        """Save trained model"""
        joblib.dump({
            'model': self.best_model,
            'model_name': self.best_model_name,
            'feature_importance': self.feature_importance,
            'results': self.results
        }, filepath)
        print(f"💾 Model saved to: {filepath}")
    
    def predict(self, X_new):
        """Make predictions on new data"""
        if self.best_model is None:
            raise ValueError("Model not trained yet!")
        
        probabilities = self.best_model.predict_proba(X_new)[:, 1]
        predictions = (probabilities >= 0.5).astype(int)
        
        return pd.DataFrame({
            'churn_probability': probabilities,
            'churn_prediction': predictions,
            'risk_level': pd.cut(probabilities, bins=[0, 0.3, 0.7, 1.0], 
                               labels=['Low', 'Medium', 'High'])
        })