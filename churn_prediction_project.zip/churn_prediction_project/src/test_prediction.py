# test_prediction.py
import joblib
import numpy as np

# Load model
model_data = joblib.load('models/churn_model.pkl')
model = model_data['model']

print("Model loaded:", model_data['model_name'])
print("Expected features:", len(model.feature_importances_))

# Create sample customer
sample_customer = np.array([[35,  # age
                            365,  # account_age_days
                            2,    # num_subscriptions
                            1,    # active_subscriptions
                            85.5, # avg_monthly_charges
                            1200, # total_spent
                            150,  # avg_data_usage
                            300,  # avg_call_minutes
                            5,    # total_support_tickets
                            4,    # avg_satisfaction (LOW!)
                            2,    # failed_payments_count
                            10,   # avg_late_fees
                            3.28, # revenue_per_day
                            0.5,  # subscription_ratio
                            1,    # is_high_usage
                            1,    # is_low_satisfaction
                            1,    # has_payment_issues
                            1,    # high_support_tickets
                            600,  # spending_per_subscription
                            2156, # age_account_interaction
                            600,  # satisfaction_x_usage
                            1,    # customer_segment (encoded)
                            0,    # gender (encoded)
                            1     # has_paperless_billing (encoded)
                            ]])

prediction = model.predict_proba(sample_customer)
print(f"\nSample Customer:")
print(f"Churn Probability: {prediction[0][1]:.2%}")
print(f"Risk Level: {'HIGH' if prediction[0][1] > 0.7 else 'MEDIUM' if prediction[0][1] > 0.3 else 'LOW'}")